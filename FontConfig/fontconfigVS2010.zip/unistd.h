/* stub unistd.h for use for MSVC compilers */

#include <io.h>