extern __typeof (FcFreeTypeCharIndex) IA__FcFreeTypeCharIndex __attribute((visibility("hidden")));
#define FcFreeTypeCharIndex IA__FcFreeTypeCharIndex
extern __typeof (FcFreeTypeCharSetAndSpacing) IA__FcFreeTypeCharSetAndSpacing __attribute((visibility("hidden")));
#define FcFreeTypeCharSetAndSpacing IA__FcFreeTypeCharSetAndSpacing
extern __typeof (FcFreeTypeCharSet) IA__FcFreeTypeCharSet __attribute((visibility("hidden")));
#define FcFreeTypeCharSet IA__FcFreeTypeCharSet
extern __typeof (FcPatternGetFTFace) IA__FcPatternGetFTFace __attribute((visibility("hidden")));
#define FcPatternGetFTFace IA__FcPatternGetFTFace
extern __typeof (FcPatternAddFTFace) IA__FcPatternAddFTFace __attribute((visibility("hidden")));
#define FcPatternAddFTFace IA__FcPatternAddFTFace
extern __typeof (FcFreeTypeQueryFace) IA__FcFreeTypeQueryFace __attribute((visibility("hidden")));
#define FcFreeTypeQueryFace IA__FcFreeTypeQueryFace
